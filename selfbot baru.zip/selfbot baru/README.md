## FGM SELFBOT LINE

- Official SelfBot Script 2020.
- Work 100% & Safe From Banned.
- Creator: Hansen & UNYPASS
- Special Thanks: HelloWorld & BE-TEAM

## INSTALL COMMAND FOR TERMUX

```sh
pkg update
pkg upgrade
pkg install python
pkg install git
git clone https://github.com/FgmCorp/fgmselfbot
cd sbfgm
python -m pip install -r pymodule.txt
python sbfgm.py
 
```

## INSTALL COMMAND FOR VPS

```sh
apt-get update
apt install python3-pip
git clone https://github.com/FgmCorp/fgmselfbot
cd sbfgm
python3 -m pip3 install -r pymodule.txt
python3 sbfgm.py
 
```
## FGM OPENCHAT
[CLICK HERE](https://hansengianto.gq/square.html)


Ⓒ FGM CORP 2020
